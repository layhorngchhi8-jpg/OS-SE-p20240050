#include<iostream>
using namespace std;

void sum1(double *sum, int n) {
    *sum = 0;
    for (int i = 1; i <= n; i++) {
        *sum += 1.0 / ((double)i * i);
    }
}

int main() {
    int n;
    cout << "Enter a positive integer n: ";
    cin >> n;

    double result;
    sum1(&result, n);

    cout << "Sum of 1/1^2 + 1/2^2 + ... + 1/" << n << "^2 = " << result << endl;

    return 0;
}
