#include<iostream>
using namespace std;

int main() {
    int n1 = 7, n2 = 3, n3 = 15;
    int *p1 = &n1, *p2 = &n2, *p3 = &n3;

    // Part a: Display address and value using pointers
    cout << "=== Part a: Address and Value ===" << endl;
    cout << "n1 -> Address: " << p1 << "  Value: " << *p1 << endl;
    cout << "n2 -> Address: " << p2 << "  Value: " << *p2 << endl;
    cout << "n3 -> Address: " << p3 << "  Value: " << *p3 << endl;

    // Part b: Update n3 = n1 + n2 using pointer p3
    *p3 = *p1 + *p2;
    cout << "\n=== Part b: Updated n3 = n1 + n2 ===" << endl;
    cout << "n3 = " << *p1 << " + " << *p2 << " = " << *p3 << endl;

    return 0;
}
