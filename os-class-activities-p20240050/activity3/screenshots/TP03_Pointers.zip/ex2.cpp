#include<iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;

    int *p = &n;
    *p = *p + 7;  // n = n + 7 via pointer

    cout << "Modified value (n + 7) = " << n << endl;

    return 0;
}
