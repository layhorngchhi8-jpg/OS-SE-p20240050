#include<iostream>
using namespace std;

void findMaxMin(int* arr, int *max, int *min) {
    *max = *arr;
    *min = *arr;
    for (int i = 1; i < 7; i++) {
        if (*(arr + i) > *max) *max = *(arr + i);
        if (*(arr + i) < *min) *min = *(arr + i);
    }
}

int main() {
    int arr[7];
    cout << "Enter 7 integer numbers:" << endl;
    for (int i = 0; i < 7; i++) {
        cout << "Number " << i + 1 << ": ";
        cin >> arr[i];
    }

    int maxVal, minVal;
    findMaxMin(arr, &maxVal, &minVal);

    cout << "\nMax value: " << maxVal << endl;
    cout << "Min value: " << minVal << endl;

    return 0;
}
