#include<iostream>
#include<cmath>
using namespace std;

void solveEquation(int a, int b, int c, float *x1, float *x2, float *delta) {
    *delta = (float)(b * b - 4 * a * c);

    if (*delta > 0) {
        *x1 = (-b + sqrt(*delta)) / (2.0f * a);
        *x2 = (-b - sqrt(*delta)) / (2.0f * a);
        cout << "Two distinct roots:" << endl;
        cout << "x1 = " << *x1 << endl;
        cout << "x2 = " << *x2 << endl;
    } else if (*delta == 0) {
        *x1 = *x2 = -b / (2.0f * a);
        cout << "One repeated root:" << endl;
        cout << "x1 = x2 = " << *x1 << endl;
    } else {
        cout << "No real roots (delta < 0)" << endl;
    }
}

int main() {
    int a, b, c;
    float x1, x2, delta;

    cout << "Solve: ax^2 + bx + c = 0" << endl;
    cout << "Enter a (not 0): "; cin >> a;
    cout << "Enter b: "; cin >> b;
    cout << "Enter c: "; cin >> c;

    solveEquation(a, b, c, &x1, &x2, &delta);
    cout << "Delta = " << delta << endl;

    return 0;
}
