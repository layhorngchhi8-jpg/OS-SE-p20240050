#include<iostream>
using namespace std;

int main() {
    float arr[7];
    cout << "Enter 7 float numbers:" << endl;
    for (int i = 0; i < 7; i++) {
        cout << "Number " << i + 1 << ": ";
        cin >> arr[i];
    }

    float *ptr = arr;  // pointer referencing the array

    // Part a: Display all numbers using pointer
    cout << "\n=== Part a: All numbers ===" << endl;
    float *p = ptr;
    for (int i = 0; i < 7; i++) {
        cout << "arr[" << i << "] = " << *(p + i) << endl;
    }

    // Part b: Summation and multiplication using pointer (no brackets)
    float sum = 0, product = 1;
    for (int i = 0; i < 7; i++) {
        sum += *(ptr + i);
        product *= *(ptr + i);
    }

    cout << "\n=== Part b: Sum and Product ===" << endl;
    cout << "Summation     = " << sum << endl;
    cout << "Multiplication = " << product << endl;

    return 0;
}
